APPLICATION_NAME="PuppetMasterless"
DEPLOY_GROUP="PuppetMasterless"
BUCKET="<bucket name>"
BUNDLE_PATH="puppet-masterless.tar"
EC2_TAG_KEY='Puppet'
EC2_TAG_VALUE='Masterless'
