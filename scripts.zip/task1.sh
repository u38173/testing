#!/bin/bash
echo "Available Disk Space"
df -H
echo "Server Load"
w

